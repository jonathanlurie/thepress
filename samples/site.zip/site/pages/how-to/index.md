The setup is super simple

Forget the fat lady! You're obsessed with the fat lady! Drive us out of here! Hey, take a look at the earthlings. Goodbye! Yes, Yes, without the oops! Did he just throw my cat out of the window? Is this my espresso machine? Wh-what is-h-how did you get my espresso machine?

Just my luck, no ice. Checkmate... Just my luck, no ice. God help us, we're in the hands of engineers. Hey, you know how I'm, like, always trying to save the planet? Here's my chance. Jaguar shark! So tell me - does it really exist? Yeah, but your scientists were so preoccupied with whether or not they could, they didn't stop to think if they should.
